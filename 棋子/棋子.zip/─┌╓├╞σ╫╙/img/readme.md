<!--
 * @Author: Paoger
 * @Date: 2023-11-04 17:58:44
 * @LastEditors: Paoger
 * @LastEditTime: 2023-11-04 18:00:18
 * @Description: 
 * 
 * Copyright (c) 2023 by Paoger, All Rights Reserved. 
-->
### 1.检测 svg文件是否能正常显示
```shell
   python main.py filenmae
```