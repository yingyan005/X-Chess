1.打开“菜单”按钮，点击“界面设置”按钮
2.打开自定义背景图开关，打开自定义棋子开关
3.点击“保存”按钮保存，退出X-Chess
4.在 X-Chess目录下，新建img目录，将背景图 background.png 和 棋子图片文件，拷贝到 X-Chess/img目录下，最终类似如下：
    X-Chess\img
	ba.svg
	background.png
	bb.svg
	bc.svg
	bk.svg
	bn.svg
	bp.svg
	br.svg
	wa.svg
	wb.svg
	wc.svg
	wk.svg
	wn.svg
	wp.svg
	wr.svg

特别说明：X-Chess仅支持100%矢量的svg，且太复杂的矢量路径显示不了，一般情况下那些内嵌图片的svg不支持，比如漂亮的、有立体的都不支持。这一点还待kivy优化，超出我能力了

最后，感谢棋子的原创者，我简化了棋子矢量路径，便于X-Chess能够正常显示
